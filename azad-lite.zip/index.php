<?php
/**
*-------------------------------------------------------------------------------------------------
* :: @package theme_textdomain
* :: @version 0.0.1
*-------------------------------------------------------------------------------------------------
*/
?>
<?php get_header(); ?>
<?php get_template_part('slug','name'); ?>
<!-- SPECIAL SECTION BEGINS -->
<section class="azad azad-section">	
    <?php //get_template_part('loop'); ?>
    <?php //get_sidebar(); ?>
</section><!-- ends special section -->
<?php get_footer(); ?>

