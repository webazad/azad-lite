<?php
/**
 * Return the default plugin settings.
 */
function scroll_top_get_default_settings() {

	$default_settings = array(
		'scroll_top_enable'     => 1,
		'scroll_top_type'       => 'icon',
		'scroll_top_text'       => esc_html__( 'Back to Top', 'scroll-top' ),
		'scroll_top_position'   => 'right',
		'scroll_top_color'      => '#ffffff',
		'scroll_top_bg_color'   => '#000000',
		'scroll_top_radius'     => 'rounded',
		'scroll_top_animation'  => 'fade',
		'scroll_top_speed'      => 300,
		'scroll_top_distance'   => 300,
		'scroll_top_css'        => "#scrollUp {\n padding: 5px 10px; \n }"
	);

	// Allow dev to filter the default settings.
	return apply_filters( 'scroll_top_default_settings', $default_settings );
}

/**
 * Function for quickly grabbing settings for the plugin without having to call get_option()
 * every time we need a setting.
 */
function scroll_top_get_plugin_settings( $option = '' ) {
	$settings = get_option( 'scroll_top_plugin_settings', scroll_top_get_default_settings() );
	return $settings[$option];
}
function scroll_top_load_scripts(){
    // Get the enable option
    $enable = scroll_top_get_plugin_settings('scroll_top_enable');
    if($enable){
        wp_enqueue_style('scroll-top-css',ST_ASSETS.'css/scroll-top.css',array(),'1.0','all');
        wp_enqueue_script('scroll-top-js',ST_ASSETS.'js/jquery.scrollUp.min.js',array('jquery'),null,true);
    }
}
add_action('wp_enqueue_scripts','scroll_top_load_scripts');
function scroll_top_custom_css(){ 
    // Get the plugin settings value
    $enable   = scroll_top_get_plugin_settings( 'scroll_top_enable' );
    $color    = scroll_top_get_plugin_settings( 'scroll_top_color' );
    $bgcolor = scroll_top_get_plugin_settings( 'scroll_top_bg_color' );
    $radius   = scroll_top_get_plugin_settings( 'scroll_top_radius' );
    $position = scroll_top_get_plugin_settings( 'scroll_top_position' );
    $css = scroll_top_get_plugin_settings( 'scroll_top_css' );
    
    // Border radius.
    $scroll_radius = '0';
    if ( $radius === 'rounded' ){
            $scroll_radius = '3px';
    } elseif ( $radius === 'circle' ) {
            $scroll_radius = '50%';
    }
    if($enable){
        ?>
        <style id="scrolltop-custom-style">
            #scrollUp{
                background: <?php echo $bgcolor; ?>;
                color: <?php echo $color; ?>;
                border-radius: <?php echo $scroll_radius; ?>;
                padding: 5px 10px;
                bottom: 20px;
                right: 20px;
            }
            <?php echo $css; ?>
        </style>
        <?php
    }
}
add_action('wp_head','scroll_top_custom_css');

function scroll_top_scrollUp_init(){ 
    // Get the plugin settings value
    $enable  = scroll_top_get_plugin_settings( 'scroll_top_enable' );
    $speed = scroll_top_get_plugin_settings( 'scroll_top_speed' );
    $dist = scroll_top_get_plugin_settings( 'scroll_top_distance' );
    $animate = scroll_top_get_plugin_settings( 'scroll_top_animation' );
    $type = esc_attr( scroll_top_get_plugin_settings( 'scroll_top_type' ) );
    $text = sanitize_text_field( scroll_top_get_plugin_settings( 'scroll_top_text' ) );
    
    // Scroll top type
    $scrolltype = '';
    if ( $type === 'text' ) {
        $scrolltype = $text;
    } else {
        $scrolltype = '<span class="scroll-top"><i class="icon-up-open"></i></span>';
    }
    // Loads the scroll top
    if($enable){
        ?>
            <script id="scrolltop-custom-js">
                jQuery(document).ready(function($){
                    $.scrollUp({
                        scrollSpeed:<?php echo $speed; ?>,
                        animation:'<?php echo $animate; ?>',
                        scrollText:'<?php echo $scrolltype; ?>',
                        scrollDistance:<?php echo $dist; ?>,
                    });
                });
            </script>
        <?php
    }
}
add_action('wp_footer','scroll_top_scrollUp_init',99);