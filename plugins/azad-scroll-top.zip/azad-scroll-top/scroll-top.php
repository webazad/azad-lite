<?php
/* 
 * Plugin Name: Azad Scroll Top
 * Plugin URI: http://www.theinfotechs.com/plugins/scroll-top
 * Description: Add a flexible back to top button to any post/page of your wordpress site.
 * Version: 1.0.3
 * Author: Md. Abul Kalam Azad
 * Author URI: http://www.theinfotechs.com/about
 * 
 */
class Scroll_Top{
    public function __construct(){
        add_action('plugins_loaded',array($this,'constants'));
        add_action('plugins_loaded',array($this,'admin'));
        add_action('plugins_loaded',array($this,'includes'));
    }
    public function constants(){
        // Set constant path to the plugin directory
        define('ST_DIR',plugin_dir_path(__FILE__));
        
        // Set constant uri to the plugin uri
        define('ST_URI',plugin_dir_url(__FILE__));
        
        // Set the constant path to the inc directory
        define('ST_INCLUDES',ST_DIR.trailingslashit('inc'));
        
        // Set the constant path to the admin directory
        define('ST_ADMIN',ST_DIR.trailingslashit("admin"));
        
        // Set the constant path to the assets directory
        define('ST_ASSETS',ST_URI.trailingslashit("assets"));
    }
    public function includes(){
        require_once(ST_INCLUDES.'functions.php');
    }
    public function admin(){
        require_once(ST_ADMIN.'admin.php');
    }
}
new Scroll_Top();

