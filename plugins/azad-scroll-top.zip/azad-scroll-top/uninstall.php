<?php
/* 
 * Uninstall procedure for the plugin.
 */
if(!defined('WP_UNINSTALL_PLUGIN')){
    exit;
}
// Delete plugin settings
delete_option('scroll_top_plugin_settings');

