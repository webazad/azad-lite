<?php
/* 
Plugin Name: Azad Social Icons
Description: All icons are made of fonts. 
Plugin URi: gittechs.com/plugin/azad-wp-starter-plugin
Author: Md. Abul Kalam Azad
Author URI: gittechs.com/author
Author Email: webdevazad@gmail.com
Version: 1.0.0
Text Domain: azad-social-icons
*/

// EXIT IF ACCESSED DIRECTLY
defined('ABSPATH') || exit;

define( 'LSI_VERSION', '1.0.0' );

if(! class_exists('Azad_Social_Icons')):
    final class Azad_Social_Icons{
        private static $_instance = null;
        public function __construct(){
            add_action('plugins_loaded',array($this,'load_textdomain'));
            add_action('plugins_loaded',array($this,'azad_includes'));
            add_action('widgets_init',array($this,'azad_register_widget'));
            add_action('admin_enqueue_scripts',array($this,'azad_admin_scripts'));
            add_action( 'admin_footer-widgets.php', array( $this, 'print_scripts' ), 9999 );
        }
        public function load_textdomain(){
            load_plugin_textdomain('azad-socials');
        }
        public function azad_includes(){
            require_once dirname( __FILE__ ) . '/azad-social-widget.php';
        }
        public function azad_admin_scripts(){
            $screen = get_current_screen();
            if( 'widgets' !== $screen->base){
                return;
            }
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'wp-color-picker' );
            wp_enqueue_script( 'underscore' );
        }
        public function azad_register_widget(){
            // Include widget classes.
            register_widget('Azad_Social_Widget');
            
        }
        public function print_scripts() {
            ?>
            <script>
                ( function( $ ){
                    function initColorPicker( widget ) {
                        widget.find( '.color-picker' ).wpColorPicker( {
                            change: _.throttle( function() { // For Customizer
                                $(this).trigger( 'change' );
                            }, 3000 )
                        });
                    }
    
                    function onFormUpdate( event, widget ) {
                        initColorPicker( widget );
                    }
    
                    $( document ).on( 'widget-added widget-updated', onFormUpdate );
    
                    $( document ).ready( function() {
                        $( '#widgets-right .widget:has(.color-picker)' ).each( function () {
                            initColorPicker( $( this ) );
                        } );
                    } );
                }( jQuery ) );
            </script>
            <?php
        }
        public static function _get_instance(){
            if(is_null(self::$_instance) && ! isset(self::$_instance) && ! (self::$_instance instanceof self)){
                self::$_instance = new self();            
            }
            return self::$_instance;
        }
        public function __destruct(){}
    }
endif;

if(! function_exists('load_azad_social_icons')){
    function load_azad_social_icons(){
        return Azad_Social_Icons::_get_instance();
    }
}
$GLOBALS['azad_social_icons'] = load_azad_social_icons();