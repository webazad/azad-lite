<?php
// EXIT IF ACCESSED DIRECTLY
defined('ABSPATH') || exit;

if(! class_exists('Azad_Social_Widget')):
    class Azad_Social_Widget extends WP_Widget{
	    private static $_instance = null;
        public function __construct(){
            parent::__construct(
                'azad_socials',
                esc_html__( 'Azad Social Icons', 'azad-social-icons' ),
                array(
                    'classname' => 'custom-text',
                    'description' => __('Azad socials is a widget based social icons.','azad-social-icons'),
                )
            );
        }
        public function form($instance){

            $options    = $this->azad_icons(); 
            $defaults   = $this->azad_default_options(); 

            $title = ( isset( $instance[ 'title' ] ) && '' !== $instance[ 'title' ] ) ? $instance[ 'title' ] : '';
            $font_size = ( isset( $instance[ 'font_size' ] ) && '' !== $instance[ 'font_size' ] ) ? $instance[ 'font_size' ] : $defaults['font_size'];
            
            $c = 0;
            foreach($options as $option){
                $defaults['input'.$c++] = '';
                $defaults['select'.$c++] = '';
            }

            $instance = wp_parse_args((array)$instance,$defaults);
            $id = $this->id;
            $new_window   = $instance['new_window']; 
            ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','azad-social-icons'); ?></label>
                <input type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr($title); ?>" class="widefat" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('font_size'); ?>"><?php _e('Icon size','azad-social-icons'); ?></label>
                <input type="number" step="1" min="14" max="30" id="<?php echo $this->get_field_id('font_size'); ?>" name="<?php echo $this->get_field_name('font_size'); ?>" value="<?php echo intval( $font_size ); ?>" class="" style="max-width:65px;"/>
                <span class="pixels" style="display:inline-block;position:relative;background:#efefef;padding:3px 7px;margin-left: -33px;">px</span>                
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('border_radius'); ?>"><?php _e('Border radius','azad-social-icons'); ?></label>
                <input type="number" step="1" min="0" max="10" id="<?php echo $this->get_field_id('border_radius'); ?>" name="<?php echo $this->get_field_name('border_radius'); ?>" value="<?php echo esc_attr($instance['border_radius']); ?>" class="" style="max-width:65px;"/>
                <span class="pixels" style="display:inline-block;position:relative;background:#efefef;padding:3px 7px;margin-left: -33px;">px</span>                
            </p>
            <hr />
            <p>
                <label for="<?php echo $this->get_field_id('color'); ?>"><?php _e('Text Color','azad-social-icons'); ?></label><br />
                <input type="text" id="<?php echo $this->get_field_id('color'); ?>" name="<?php echo $this->get_field_name('color'); ?>" value="<?php echo esc_attr($instance['color']); ?>" class="color-picker" style="max-width:65px;"/>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('color_hover'); ?>"><?php _e('Text Hover Color','azad-social-icons'); ?></label><br />
                <input type="text" id="<?php echo $this->get_field_id('color_hover'); ?>" name="<?php echo $this->get_field_name('color_hover'); ?>" value="<?php echo esc_attr($instance['color_hover']); ?>" class="color-picker" style="max-width:65px;"/>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('background'); ?>"><?php _e('Background Color','azad-social-icons'); ?></label><br />
                <input type="text" id="<?php echo $this->get_field_id('background'); ?>" name="<?php echo $this->get_field_name('background'); ?>" value="<?php echo esc_attr($instance['background']); ?>" class="color-picker" style="max-width:65px;"/>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('background_hover'); ?>"><?php _e('Background Hover Color','azad-social-icons'); ?></label><br />
                <input type="text" id="<?php echo $this->get_field_id('background_hover'); ?>" name="<?php echo $this->get_field_name('background_hover'); ?>" value="<?php echo esc_attr($instance['background_hover']); ?>" class="color-picker" style="max-width:65px;"/>
            </p>
            <hr />
            <p>
                <label for="<?php echo $this->get_field_id('new_window'); ?>">
                    <input id="<?php echo $this->get_field_id('new_window'); ?>" type="checkbox" name="<?php echo $this->get_field_name('new_window'); ?>" value="1" <?php checked(1,$instance['new_window']); ?> />
                    <?php _e('Open links in new window?','azad-social-icons'); ?>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('tooltip'); ?>">
                    <input id="<?php echo $this->get_field_id('tooltip'); ?>" type="checkbox" name="<?php echo $this->get_field_name('tooltip'); ?>" value="1" <?php checked(1,$instance['tooltip']); ?> />
                    <?php _e('Enable tooltips?','azad-social-icons'); ?>
                </label>
            </p>
            <p>
                <select name="<?php echo $this->get_field_name('alignment'); ?>" id="<?php echo $this->get_field_id('alignment'); ?>">
                    <option  value="left" <?php selected($instance['alignment'], 'left' ); ?>><?php _e( 'Left', 'azad-social-icons' ); ?></option>
                    <option  value="center" <?php selected($instance['alignment'], 'center' ); ?>><?php _e( 'Center', 'azad-social-icons' ); ?></option>
                    <option  value="right" <?php selected($instance['alignment'], 'right' ); ?>><?php _e( 'Right', 'azad-social-icons' ); ?></option>
                </select>
                <?php esc_html_e( 'Alignment', 'azad-social-icons' ); ?>
            </p>
            <hr />
            <ul class="social-icon-fields" style="margin-left:0;"> 
            <?php
                $count = 0;
                foreach($options as $option){ 
                    $input = 'input' . $count++;
                    $select = 'select' . $count++;
                ?>
                    <li class="lsi-container" style="display:flex;">
                        <select class="choose-icon" id="<?php echo $this->get_field_id($select); ?>" name="<?php echo $this->get_field_name($select); ?>">
                            <option  value=""></option>
                            <?php foreach($options as $option) : ?>
                                <option  value="<?php echo $option['id']; ?>" <?php selected($instance[$select], $option['id'] ); ?>><?php echo $option['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input class="widefat social-item" type="text" id="<?php echo $this->get_field_id($input); ?>" name="<?php echo $this->get_field_name($input); ?>" value="<?php echo esc_attr( $instance[$input] ); ?>"/>
                    </li>
                <?php }
            ?>
            <span style="float:right;font-size: 90%;padding-top:3px;">
				Developed by: <a href="https://gittechs.com" target="_blank">Azad</a>
			</span>
            <button onclick="event.preventDefault();lsiAddIcon(this)" class="button add-lsi-row <?php echo $id;?>" data-id="<?php echo $id;?>" style="margin-bottom:10px;"><?php _e( 'Add Icon', 'lsi' ); ?></button>
            </ul>
            <script>
                jQuery(document).ready(function ($) {
                    $( '.social-item' ).each( function( index ) {
                        if( ! $(this).val() ) {
                            $( this ).parent().hide();
                        }
                    });

                    $('.lsi-container .choose-icon').each(function(){
                        $(this).change(function() {
                            var select = $(this);

                            if ( $(this).attr('value') == 'phone' ) {
                                $(this).next('input').attr('placeholder', '<?php _e( '1 (123)-456-7890','lightweight-social-icons'); ?>');
                            } else if ( $(this).attr('value') == 'email' ) {
                                $(this).next().attr('placeholder', '<?php _e( 'you@yourdomain.com or http://', 'lightweight-social-icons' ); ?>');
                            } else if ( $(this).attr('value') == 'skype' ) {
                                $(this).next().attr('placeholder', '<?php _e( 'Username', 'lightweight-social-icons' ); ?>');
                            }else if ( $(this).attr('value') == '' ) {
                                $(this).next().attr('placeholder','');
                            } else {
                                $(this).next().attr('placeholder','http://');
                            }
                        });
                    });
                });
                function lsiAddIcon(elem) {
                    jQuery( elem ).siblings('li:hidden:first').css( 'display', 'flex' );
                }
            </script>
        <?php }
        public function update($new_instance,$old_instance){
            $options                      = $this->azad_icons();
            $instance                     = $old_instance;
            
            $instance['title']            = strip_tags($new_instance['title']);
            $instance['border_radius']    = intval($new_instance['border_radius']);
            $instance['font_size']        = intval($new_instance['font_size']);
            $instance['background']       = $this->azad_sanitize_hex_color($new_instance['background']);
            $instance['color']            = $this->azad_sanitize_hex_color($new_instance['color']);
            $instance['background_hover'] = $this->azad_sanitize_hex_color($new_instance['background_hover']);
            $instance['color_hover']      = $this->azad_sanitize_hex_color($new_instance['color_hover']);
            $instance['new_window']       = $new_instance['new_window'];
            $instance['alignment']        = strip_tags($new_instance['alignment']);
            $instance['tooltip']          = strip_tags($new_instance['tooltip']);
            
            $count = 0;
            foreach($options as $option){
                $input = 'input' . $count++;
                $select = 'select' . $count++;
                $instance[$select] = strip_tags($new_instance[$select]);
                $instance[$input] = esc_url( $new_instance[$input] );
            }
            return $instance;
        }
        public function widget($args, $instance){ 
            $title              = apply_filters('widget_title',$instance['title']);
            $options            = $this->azad_icons();
            $defaults           = $this->azad_default_options();
            $unique_id          = esc_attr($args['widget_id']);
            $output             = '';
            
            echo $args['before_widget'];
            echo (! empty($title)) ? $args['before_title'] . $title . $args['after_title'] : '';
            
            $new_window         = ( isset( $instance['new_window'] ) && '' !== $instance['new_window'] ) ? 'target="_blank"' : $defaults['new_window'];
            $font_size          = (isset($instance['font_size']) && '' !== $instance['font_size']) ? $instance['font_size'] : $defaults['font_size'];
            $border_radius      = (isset($instance['border_radius']) && '' !== $instance['border_radius']) ? $instance['border_radius'] : $defaults['border_radius'];
            $background         = (isset($instance['background']) && '' !== $instance['background']) ? $instance['background'] : $defaults['background'];
            $color              = (isset($instance['color']) && '' !== $instance['color']) ? $instance['color'] : $defaults['color'];
            $background_hover   = (isset($instance['background_hover']) && '' !== $instance['background_hover']) ? $instance['background_hover'] : $defaults['background_hover'];
            $color_hover        = (isset($instance['color_hover']) && '' !== $instance['color_hover']) ? $instance['color_hover'] : $defaults['color_hover'];
            $alignment          = (isset($instance['alignment']) && '' !== $instance['alignment']) ? $instance['alignment'] : $defaults['alignment'];
            $tooltip            = (isset($instance['tooltip']) && '' !== $instance['tooltip']) ? $instance['tooltip'] : $defaults['tooltip'];
            
            $count = 0;
            foreach($options as $option){
                $input  = 'input' . $count++;
                $select = 'select' . $count++;
                
                $id     = (! empty($instance[$option['id']])) ? $instance[$option['id']] : '';
                $name   = (! empty($instance[$select])) ? $instance[$select] : '';
                $value  = (! empty($instance[$input])) ? $instance[$input] : '';
                if(! empty($value) && ! empty($name)){
                    if ( is_email( $value ) ) {
                        $the_value = 'mailto:' . $value;
                    } elseif ( 'phone' == $name ) {
                        $the_value = 'tel:' . $value;
                    } elseif ( 'skype' == $name ) {
                        $the_value = 'skype:' . $value;
                    } else {
                        $the_value = esc_url( $value );
                    }

                    $show_tooltip       = ( ! empty( $tooltip ) ) ? 'tooltip' : '';
                    $rel_attribute      = apply_filters( 'lsi_icon_rel_attribute','rel="nofollow"' );
                    $title_attribute    = apply_filters( 'lsi_icon_title_attribute','title="' . $options[$name]
                    ['name'] . '"' );
                    $accessibility      = apply_filters( 'lsi_icon_aria_attribute','aria-label="' . $options[$name]['name'] . '"' );
                
                    $output .= sprintf('<li class="lsi-social-%3$s"><a class="%4$s" %5$s %6$s %7$s href="%1$s" %2$s><i class="lsicon %3$s"></i></a></li>',
                        $the_value,
                        'email' == $name ? '' : $new_window,
                        ($name == 'home') ? 'af-'.$name : 'lsicon-'.$name,
                        $show_tooltip,
                        $rel_attribute,
                        $title_attribute,
                        $accessibility
                    );
                }                
            }
            if($output){
                printf('<ul class="azad-social-icons icon-set-%1$s" style="text-align:%3$s;">%2$s</ul>',
                    $unique_id,
                    apply_filters('azad_icon_output',$output),
                    $alignment,
                );
            }
            //$css = ".azad-social-icons a,.azad-social-icons a:visited,.azad-social-icons a:focus{background:$background;color:$color;border-radius:{$border_radius}px;font-size:{$font_size}px;}.azad-social-icons a:hover{color:$color_hover;background:$background_hover;}";

            $css = ".icon-set-{$unique_id} a,.icon-set-{$unique_id} a:visited,.icon-set-{$unique_id} a:focus{background:$background;color:$color;border-radius:{$border_radius}px;font-size:{$font_size}px;}.icon-set-{$unique_id} a:hover{color:$color_hover;background:$background_hover;}";

            wp_enqueue_style('azad-style',plugin_dir_url(__FILE__).'css/style.css',array(),'34','all');
            wp_add_inline_style('azad-style', $css, 99);

            if ( ! empty( $tooltip ) ) {
                wp_enqueue_script( 'lsi-tooltipster', plugin_dir_url( __FILE__ ) . 'js/jquery.tooltipster.min.js', array( 'jquery' ), LSI_VERSION, true );
            }

            echo $args['after_widget'];
        }
        public function azad_default_options(){
            $defaults = array(
                'title'             => 'Azad',
                'new_window'        => '',
                'border_radius'     => 2,
                'font_size'         => 20,
                'background'        => '#1E72BD',
                'color'             => '#FFFFFF',
                'background_hover'  => '#777777',
                'color_hover'       => '#FFFFFF',
                'alignment'         => 'left',
                'tooltip'           => ''
            );
            return apply_filters('azad_default_options',$defaults);
        }
        public function azad_icons($options = ''){
            $options = array(
                'home' => array(
                    'id' => 'home',
                    'name' => __( 'Home', 'lightweight-social-icons' )
                ),
                'fivehundredpx' => array(
                    'id' => 'fivehundredpx',
                    'name' => __( '500px', 'lightweight-social-icons' )
                ),
                'angellist' => array(
                    'id' => 'angellist',
                    'name' => __( 'AngelList', 'lightweight-social-icons' )
                ),
                'bandcamp' => array(
                    'id' => 'bandcamp',
                    'name' => __( 'Bandcamp', 'lightweight-social-icons' )
                ),
        		'behance' => array(
        			'id' => 'behance',
        			'name' => __( 'Behance', 'lightweight-social-icons' )
        		),
        		'bitbucket' => array(
        			'id' => 'bitbucket',
        			'name' => __( 'BitBucket', 'lightweight-social-icons' )
        		),
        		'bloglovin' => array(
        			'id' => 'bloglovin',
        			'name' => __( "Blog Lovin'", 'lightweight-social-icons' )
        		),
        		'codepen' => array(
        			'id' => 'codepen',
        			'name' => __( 'Codepen', 'lightweight-social-icons' )
        		),
        		'email' => array(
        			'id' => 'email',
        			'name' => __( 'Contact', 'lightweight-social-icons' )
        		),
        		'delicious' => array(
        			'id' => 'delicious',
        			'name' => __( 'Delicious', 'lightweight-social-icons' )
        		),
        		'deviantart' => array(
        			'id' => 'deviantart',
        			'name' => __( 'DeviantArt', 'lightweight-social-icons' )
        		),
        		'digg' => array(
        			'id' => 'digg',
        			'name' => __( 'Digg', 'lightweight-social-icons' )
        		),
        		'dribbble' => array(
        			'id' => 'dribbble',
        			'name' => __( 'Dribbble', 'lightweight-social-icons' )
        		),
        		'dropbox' => array(
        			'id' => 'dropbox',
        			'name' => __( 'Dropbox', 'lightweight-social-icons' )
        		),
        		'facebook' => array(
        			'id' => 'facebook',
        			'name' => __( 'Facebook', 'lightweight-social-icons' )
        		),
        		'flickr' => array(
        			'id' => 'flickr',
        			'name' => __( 'Flickr', 'lightweight-social-icons' )
        		),
        		'foursquare' => array(
        			'id' => 'foursquare',
        			'name' => __( 'Foursquare', 'lightweight-social-icons' )
        		),
        		'github' => array(
        			'id' => 'github',
        			'name' => __( 'Github', 'lightweight-social-icons' )
        		),
        		'gplus' => array(
        			'id' => 'gplus',
        			'name' => __( 'Google+', 'lightweight-social-icons' )
        		),
        		'houzz' => array(
        			'id' => 'houzz',
        			'name' => __( 'Houzz', 'lightweight-social-icons' )
        		),
        		'instagram' => array(
        			'id' => 'instagram',
        			'name' => __( 'Instagram', 'lightweight-social-icons' )
        		),
        		'itunes' => array(
        			'id' => 'itunes',
        			'name' => __( 'iTunes', 'lightweight-social-icons' )
        		),
        		'jsfiddle' => array(
        			'id' => 'jsfiddle',
        			'name' => __( 'JSFiddle', 'lightweight-social-icons' )
        		),
        		'lastfm' => array(
        			'id' => 'lastfm',
        			'name' => __( 'Last.fm', 'lightweight-social-icons' )
        		),
        		'linkedin' => array(
        			'id' => 'linkedin',
        			'name' => __( 'LinkedIn', 'lightweight-social-icons' )
        		),
        		'mixcloud' => array(
        			'id' => 'mixcloud',
        			'name' => __( 'Mixcloud', 'lightweight-social-icons' )
        		),
        		'paper-plane' => array(
        			'id' => 'paper-plane',
        			'name' => __( "Newsletter", 'lightweight-social-icons' )
        		),
        		'phone' => array(
        			'id' => 'phone',
        			'name' => __( 'Phone', 'lightweight-social-icons' )
        		),
        		'pinterest' => array(
        			'id' => 'pinterest',
        			'name' => __( 'Pinterest', 'lightweight-social-icons' )
        		),
        		'reddit' => array(
        			'id' => 'reddit',
        			'name' => __( 'Reddit', 'lightweight-social-icons' )
        		),
        		'rss' => array(
        			'id' => 'rss',
        			'name' => __( 'RSS', 'lightweight-social-icons' )
        		),
        		'skype' => array(
        			'id' => 'skype',
        			'name' => __( 'Skype', 'lightweight-social-icons' )
        		),
        		'snapchat' => array(
        			'id' => 'snapchat',
        			'name' => __( 'Snapchat', 'lightweight-social-icons' )
        		),
        		'soundcloud' => array(
        			'id' => 'soundcloud',
        			'name' => __( 'Soundcloud', 'lightweight-social-icons' )
        		),
        		'spotify' => array(
        			'id' => 'spotify',
        			'name' => __( 'Spotify', 'lightweight-social-icons' )
        		),
        		'stackoverflow' => array(
        			'id' => 'stackoverflow',
        			'name' => __( 'Stack Overflow', 'lightweight-social-icons' )
        		),
        		'steam' => array(
        			'id' => 'steam',
        			'name' => __( 'Steam', 'lightweight-social-icons' )
        		),
        		'stumbleupon' => array(
        			'id' => 'stumbleupon',
        			'name' => __( 'Stumbleupon', 'lightweight-social-icons' )
        		),
        		'tripadvisor' => array(
        			'id' => 'tripadvisor',
        			'name' => __( 'Trip Advisor', 'lightweight-social-icons' )
        		),
        		'tumblr' => array(
        			'id' => 'tumblr',
        			'name' => __( 'Tumblr', 'lightweight-social-icons' )
        		),
        		'twitch' => array(
        			'id' => 'twitch',
        			'name' => __( 'Twitch', 'lightweight-social-icons' )
        		),
        		'twitter' => array(
        			'id' => 'twitter',
        			'name' => __( 'Twitter', 'lightweight-social-icons' )
        		),
        		'vimeo' => array(
        			'id' => 'vimeo',
        			'name' => __( 'Vimeo', 'lightweight-social-icons' )
        		),
        		'vine' => array(
        			'id' => 'vine',
        			'name' => __( 'Vine', 'lightweight-social-icons' )
        		),
        		'vkontakte' => array(
        			'id' => 'vkontakte',
        			'name' => __( "VK", 'lightweight-social-icons' )
        		),
        		'wordpress' => array(
        			'id' => 'wordpress',
        			'name' => __( 'WordPress', 'lightweight-social-icons' )
        		),
        		'xing' => array(
        			'id' => 'xing',
        			'name' => __( 'Xing', 'lightweight-social-icons' )
        		),
        		'yelp' => array(
        			'id' => 'yelp',
        			'name' => __( 'Yelp', 'lightweight-social-icons' )
        		),
        		'youtube' => array(
        			'id' => 'youtube',
        			'name' => __( 'YouTube', 'lightweight-social-icons' )
        		),
        		'yahoo' => array(
        			'id' => 'yahoo',
        			'name' => __( 'Yahoo', 'lightweight-social-icons' )
        		)
            );
            return apply_filters('azad_icons_defaults',$options);
        }
        public function azad_sanitize_hex_color($color){
            if('' == $color){
                return '';
            }
            if(preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|',$color)){
                return $color;
            }
            return null;
        }
        public static function _get_instance(){
            if(is_null(self::$_instance) && ! isset(self::$_instance) && ! (self::$_instance instanceof self)){
                self::$_instance = new self();            
            }
            return self::$_instance;
        }
    }
endif;

if(! function_exists('load_azad_social_widget')){
    function load_azad_social_widget(){
        return Azad_Social_Widget::_get_instance();
    }
}
//$GLOBALS['azad_social_widget'] = load_azad_social_widget();